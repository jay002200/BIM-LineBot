from datetime import date
from flask import Flask, request, abort
from linebot import exceptions
from linebot import (
    LineBotApi, WebhookHandler
)
from linebot.exceptions import (
    InvalidSignatureError
)
from linebot.models import *
import re
import random
import time
import os
import tempfile
import gspread
import configparser
from oauth2client.service_account import ServiceAccountCredentials as SAC
from requests.api import get


app = Flask(__name__)
now_time = time.strftime("%b %d %a %H:%M:%S %Y", time.localtime())

config = configparser.ConfigParser()
config.read('config.ini')

# The line bot access token and webhook id

line_bot_api = LineBotApi(config.get('line-bot', 'channel_access_token'))
handler = WebhookHandler(config.get('line-bot', 'channel_secret'))


@app.route("/", methods=['POST'])
def callback():
    # get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']

    # get request body as text
    body = request.get_data(as_text=True)
    app.logger.info("Request body: " + body)

    # handle webhook body
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)

    return 'OK'


@handler.add(MessageEvent, message=(TextMessage, ImageMessage))
def handle_message(event):
    # receive key word -> send message or do something
    if isinstance(event.message, TextMessage):
        now_time = time.strftime("%b %d %a %H:%M:%S %Y", time.localtime())
        user_id = event.source.user_id
        replymessage = event.message.text

        profile = line_bot_api.get_profile(user_id)

        user_list = []
        user_list.append(profile.display_name)
        user_list.append(profile.picture_url)
        user_list.append(replymessage)
        user_list.append(now_time)
        user_list.append(user_id)
        user_list.append("中正峯華")

# 點選區域圖 複製用 = ImagemapSendMessage(
        #     base_url='https://imgur.com/JgTDFur.jpg',
        #     alt_text='圖片',
        #     base_size=BaseSize(height=720, width=1280),
        #     actions=[
        #     ]
        # )


# 樓層選項 複製用 sunsan_option = TemplateSendMessage(
        #     alt_text='Buttons template',
        #     template=ButtonsTemplate(
        #         title='樓層選項',
        #         thumbnail_image_url='https://imgur.com/XNWP2Im.jpg',
        #         text=' ',
        #         actions=[
        #             MessageTemplateAction(
        #                 label='標準層',
        #                 text='森山標準層'
        #             ),
        #
        #         ]
        #     )
        # )
# ----------------選項----------------------
    kunchen_option = TemplateSendMessage(
        alt_text='Buttons template',
        template=ButtonsTemplate(
            title='樓層選項',
            thumbnail_image_url='https://imgur.com/XNWP2Im.jpg',
            text=' ',
            actions=[
                MessageTemplateAction(
                    label='B2',
                    text='中正峯華B2'
                ),
                MessageTemplateAction(
                    label='B3',
                    text='中正峯華B3'
                ),
            ]
        )
    )

# -----------------點選區---------------------- 
    kunchen_B2Area = ImagemapSendMessage(
        base_url='https://imgur.com/fnjgekr.jpg',
        alt_text='圖片',
        base_size=BaseSize(height=720, width=1280),
        actions=[
            # A
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/ZGcMuZwNvnrYifNU7',
                area=ImagemapArea(
                    x=241, y=357, width=80, height=80
                )
            ),
            # B
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/xx5BZZ693ZHQq37m8',
                area=ImagemapArea(
                    x=446, y=338, width=80, height=80
                )
            ),
            # C
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/BTWMqxaat3jmNAwZ9',
                area=ImagemapArea(
                    x=390, y=459, width=80, height=80
                )
            ),
            # D
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/b3hK1uncJXXa7NHN8',
                area=ImagemapArea(
                    x=613, y=352, width=80, height=80
                )
            ),
            # E
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/ktsBur2MKwKeyfTf6',
                area=ImagemapArea(
                    x=661, y=204, width=80, height=80
                )
            ),
            # F
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/FY8BCLoCscmbCb927',
                area=ImagemapArea(
                    x=830, y=331, width=80, height=80
                )
            ),
            # G
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/TtacfM7GqaBtEfPF9',
                area=ImagemapArea(
                    x=1035, y=315, width=80, height=80
                )
            ),
            # H
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/JYpfsYGCXXBSCgYN7',
                area=ImagemapArea(
                    x=934, y=429, width=80, height=80
                )
            ),
        ]
    )

    kunchen_B3Area = ImagemapSendMessage(
        base_url='https://imgur.com/oHKCfNR.jpg',
        alt_text='圖片',
        base_size=BaseSize(height=720, width=1280),
        actions=[
            # A
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/Dv797zj7Fnqk59oz7',
                area=ImagemapArea(
                    x=234, y=350, width=80, height=80
                )
            ),
            # B
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/CSZGKLuSzeGpHHWY6',
                area=ImagemapArea(
                    x=439, y=342, width=80, height=80
                )
            ),
            # C
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/4REvo6Gf3gK7GB617',
                area=ImagemapArea(
                    x=652, y=232, width=80, height=80
                )
            ),
            # D
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/MjKVTScAJcuYG2ss6',
                area=ImagemapArea(
                    x=855, y=337, width=80, height=80
                )
            ),
            # E
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/4KGb8sdNkrWs6YpK6',
                area=ImagemapArea(
                    x=1020, y=338, width=80, height=80
                )
            ),
            # F
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/CQqfjvyGtT4HdUNu8',
                area=ImagemapArea(
                    x=546, y=453, width=80, height=80
                )
            ),

        ]
    )
# --------------------------------
    location_message = LocationSendMessage(
        title='台灣彰化縣',
        address='500台灣彰化縣彰化市中正路一段384號',
        latitude=24.082974,
        longitude=120.543850
    )

# --------------------------------------
    if replymessage == "全景預覽":
        line_bot_api.reply_message(
            event.reply_token, [
                kunchen_option
            ])
    elif replymessage == "中正峯華B2":
        line_bot_api.reply_message(
            event.reply_token, [
                autoimage()
            ])
    elif replymessage == "中正峯華B3":
        line_bot_api.reply_message(
            event.reply_token, [
                kunchen_B3Area
            ])
    elif replymessage == "工程數量":
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(
                text="工程數量:\nhttps://drive.google.com/drive/folders/1kiOBtjeQIZ508hQ2-9bNHAZU8NRmHFj-")
        )
    elif replymessage == "模型網址":
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text="模型網址:\nhttps://a360.co/2WfElew")
        )
    elif replymessage == "地點":
        line_bot_api.reply_message(
            event.reply_token,
            [location_message
             ]
        )
    elif replymessage == "模板模型":
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text="模型網址:\nhttps://a360.co/3vouzUJ")
        )
    else:
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text="敬請期待")
        )

    googlesheet(user_list)


def googlesheet(info):
    Json = 'googlesheet.json'  # Json 的單引號內容請改成妳剛剛下載的那個金鑰
    Url = ['https://spreadsheets.google.com/feeds']
    Connect = SAC.from_json_keyfile_name(Json, Url)
    GoogleSheets = gspread.authorize(Connect)
    Sheet = GoogleSheets.open_by_key(
        '1j1o5P4rs6DXs3oo0kVQccBJslnZVED4jmnmKjT8-9To')  # 這裡請輸入妳自己的試算表代號
    Sheets = Sheet.sheet1
    Sheets.append_row(info)


def getcount():
    Json = 'googlesheet.json'  # Json 的單引號內容請改成妳剛剛下載的那個金鑰
    Url = ['https://spreadsheets.google.com/feeds']
    Connect = SAC.from_json_keyfile_name(Json, Url)
    GoogleSheets = gspread.authorize(Connect)
    Sheet = GoogleSheets.open_by_key(
        '1ECXYPO73JaKIr8QJ0a886xl-a0CMlfOhcU5TjtMLfu8')  # 這裡請輸入妳自己的試算表代號
    worksheet = Sheet.get_worksheet(0)
    count = worksheet.col_values(1)
    return count

def autoimage():
    url = "https://imgur.com/fnjgekr.jpg"
    kunchen_B2Area = ImagemapSendMessage(
        base_url=url,
        alt_text='圖片',
        base_size=BaseSize(height=720, width=1280),
        actions=[
            # A
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/ZGcMuZwNvnrYifNU7',
                area=ImagemapArea(
                    x=241, y=357, width=80, height=80
                )
            ),
            # B
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/xx5BZZ693ZHQq37m8',
                area=ImagemapArea(
                    x=446, y=338, width=80, height=80
                )
            ),
            # C
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/BTWMqxaat3jmNAwZ9',
                area=ImagemapArea(
                    x=390, y=459, width=80, height=80
                )
            ),
            # D
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/b3hK1uncJXXa7NHN8',
                area=ImagemapArea(
                    x=613, y=352, width=80, height=80
                )
            ),
            # E
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/ktsBur2MKwKeyfTf6',
                area=ImagemapArea(
                    x=661, y=204, width=80, height=80
                )
            ),
            # F
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/FY8BCLoCscmbCb927',
                area=ImagemapArea(
                    x=830, y=331, width=80, height=80
                )
            ),
            # G
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/TtacfM7GqaBtEfPF9',
                area=ImagemapArea(
                    x=1035, y=315, width=80, height=80
                )
            ),
            # H
            URIImagemapAction(
                link_uri='https://photos.app.goo.gl/JYpfsYGCXXBSCgYN7',
                area=ImagemapArea(
                    x=934, y=429, width=80, height=80
                )
            ),
        ]
    )
    return kunchen_B2Area



@ handler.add(PostbackEvent)
def handle_postback(event):
    # postback 資料
    data = event.postback.data
    # 使用者Id
    userId = event.source.user_id

    # 上一頁
    # if data == "action=prev":
    #     # 移除個別用戶選單
    #     line_bot_api.unlink_rich_menu_from_user(userId)

    # if data == "action=next":
    #     line_bot_api.link_rich_menu_to_user(userId, "richmenu-7937ea517e098555885495be5a843cac")


if __name__ == "__main__":
    app.run()
